#ifndef COORD_H
#define COORD_H

struct coord {
  int x;
  int y;
};

#endif